export const CEREAL_LIGHT_BLUE = "#97c8eb";
export const CEREAL_AQUA = "#64e9ee";
export const CEREAL_DARK_AQUA = "#3aafb9";
export const CEREAL_DARK_GREEN = "#093a3e";
export const CEREAL_BLACK = "#001011";
